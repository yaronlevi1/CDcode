

var num1 = 5;
var num2 = 3/2;
var num3 = -1;
var num4 = 1/0 ;
console.log("Number 1 is", num1);
console.log("Number 2 is", num2);
console.log("Number 3 is", num3);
console.log("Number 4 is", num4);
var str1 = "AAA"
var str2 =  "  \" \' \"will this work?\" \' \" "
var str3 = " It did!"
console.log("string 1 is", str1);
console.log("string 2 is", str2);
console.log("string 3 is", str3);
var bool1 = false
var bool2 = true
console.log(bool1)
console.log(bool2)
var und1 = undefined
console.log(und1)


